import { useState } from 'react'
import TopPage from '@/pages/TopPage/TopPage'
import Result from '@/pages/ResultPage/ResultPage'
import './Content.css'

const Content = () => {
    const [participants, setParticipants] = useState([
        {id: "first", name: "本部長", count: "1", weight: 50, payment: 0},
        {id: "second", name: "課長", count: "1", weight: 50, payment: 0} 
    ])
    const [rules, setRules] = useState([])
    const [amount, setAmount] = useState(100000)
    const [status, setStatus] = useState("top")
    const [forms, setForms] = useState([
        {id: "first", flag: true},
        {id: "second", flag: true},
        {id: "totalAmount", flag: true}
    ])
    const addForms = (inputId) => {
        const newForms = [...forms,{id: inputId, flag: false}]
        setForms(newForms)
    }
    const deleteForms = (target) => {
        const newForms = forms.filter((form) => (form.id !== target))
        setForms(newForms);
    }
    const updateForms = (target,val) => {
        const newForms = forms.map((form) => {
            if (form.id === target) {
                form.flag = val
            }
            return form
        })
        setForms(newForms)
    }
    const viewControl = () => {
        if (status === "top") {
            return <TopPage
            status={status}
            setStatus={setStatus}
            participants={participants}
            setParticipants={setParticipants}
            rules={rules}
            setRules={setRules}
            amount={amount}
            setAmount={setAmount}
            forms={forms}
            setForms={setForms}
            addForms={addForms}
            deleteForms={deleteForms}
            updateForms={updateForms}
             />
        } else if (status === "loading") {
            return <h1>loading...</h1>
        } else if (status === "result") {
            return <Result
            participants={participants}
            setStatus={setStatus} />
        }
    }
    
    return (
        <div className='content area'>
            { viewControl() }
        </div>
    )
}

export default Content;