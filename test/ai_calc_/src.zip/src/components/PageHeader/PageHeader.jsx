import './PageHeader.css'

const PageHeader = ({title}) => {
    return (
        <header>
            <div>{title}</div>
            <button onClick={() => {window.location.reload()}}>Top</button>
            <button>Help</button>
        </header>
    )
}

export default PageHeader;