import EarchPayment from './components/EachPayment'
import './ResultPage.css'

const Result = ({ participants, setStatus }) => {
    var totalAmount = 0;
    
    participants.map((participant) => {
        totalAmount += parseInt(participant.payment,10) * participant.count
    })

    return (
        <div className='result'>
            <table>
                <thead>
                    <tr>
                        <td colSpan="2"><h2>計算結果</h2></td>
                    </tr>
                </thead>
                <EarchPayment participants={participants} />
                <tfoot>
                    <tr>
                        <td>合計金額</td>
                        <td>{totalAmount}円</td>
                    </tr>
                </tfoot>
            </table>
            <button onClick={()=>{setStatus("top")}}>戻る</button>
            <button onClick={()=>{setStatus("top")}}>再生成</button>
        </div>
    )
}

export default Result;