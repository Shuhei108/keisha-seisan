import './Execute.css'

const Execute = ({ setStatus, participants, setParticipants, rules, amount, forms}) => {
    const calculate = async () => {
        setStatus("loading")
        
        const url = 'http://127.0.0.1:8000/v1/calc'
        const reqData = {
            participants:{},
            rules: null,
            amount: null
        }

        for (let i = 0; i < participants.length; i++) { 
            reqData["participants"][participants[i].name] = {"人数": Number(participants[i].count), "重み": Number(participants[i].weight)  }
        }

        reqData["rules"] = rules.map((rule) => {return rule.value})

        reqData["amount"] = parseInt(amount,10)

        console.log(reqData)
        
        try {
            const response = await fetch(url,{
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                mode: 'cors',
                body: JSON.stringify(reqData)
            });
            const resData = await response.json();
            console.log(resData)
            const newParticipants = participants.map((participant, i) => {
                participant.payment = resData["settlement_plan"][i]["amount"]
                return participant
            })
            setParticipants(newParticipants)
        } catch (error) {
            console.error('リクエストエラー:', error);
        }
        setStatus("result")
    }
    return (
        <>
            {
                forms.every((form) => (form.flag === true)) && participants.length > 0 ?
                <button className="exe-btn" onClick={calculate} disabled={false}>計算する</button>:
                <button className="dummy-btn" onClick={calculate} disabled={true}>計算する</button>
            }
            
        </>
    )
}

export default Execute;