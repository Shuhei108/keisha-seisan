import { useState } from 'react'
import Rule from './Rule'

const Rules = ({ rules, setRules, addForms, deleteForms, updateForms }) => {

    const deleteRule = (id) => {
        const newRules = rules.filter((rule) => (rule.id !== id));
        deleteForms(id);
        setRules(newRules);
    }
    const addRule = () => {
        const newRule = {id: crypto.randomUUID(), value: ""}
        const newRules = [...rules, newRule]
        addForms(newRule.id);
        setRules(newRules);
    }
    const changeRule = (id,val) => {
        const newRules = rules.map((rule)=> {
            if (rule.id === id) {
                rule.value = val
                if (val !== "") {
                    updateForms(id,true)
                } else {
                    updateForms(id,false)
                }
            }
            return rule
        })
        setRules(newRules)
    }

    return (
        <>
            <table>
                <thead>
                    <tr>
                        <td></td>
                        <td colSpan="3">
                            <h2>精算ルール</h2>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    {rules.map((rule) => {
                        return (
                            <Rule
                                key={rule.id}
                                rule={rule}
                                deleteRule={() => {deleteRule(rule.id)}}
                                changeRule={(val) => {changeRule(rule.id,val)}}
                                updateForms={(val) => {updateForms(rule.id,val)}} /> 
                        )
                    })}
                    <tr>
                        <td className='col-1'><button onClick={addRule}>+</button></td>
                        <td colSpan="3"></td>
                    </tr>
                </tbody>
            </table>
        </>
    )
}

export default Rules;