import Participants from './components/Participants'
import Rules from './components/Rules'
import TotalAmount from './components/TotalAmount'
import Execute from './components/Execute'
import './TopPage.css'

const TopPage = ({ setStatus, participants, setParticipants, rules, setRules, amount,
    setAmount, forms, addForms, deleteForms, updateForms}) => {
    return (
        <div className='top-page'>
            <Participants
                participants={participants}
                setParticipants={setParticipants}
                addForms={addForms}
                deleteForms={deleteForms}
                updateForms={updateForms}/>
            <Rules
                rules={rules}
                setRules={setRules}
                addForms={addForms}
                deleteForms={deleteForms}
                updateForms={updateForms}/>
            <TotalAmount
                amount={amount}
                setAmount={setAmount}
                updateForms={updateForms}/>
            <Execute
                setStatus={setStatus}
                participants={participants}
                setParticipants={setParticipants}
                rules={rules}
                amount={amount} 
                forms={forms}/>
        </div>
    )
}

export default TopPage;